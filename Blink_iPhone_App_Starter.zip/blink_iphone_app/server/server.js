require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const Video = require('./models/Video');
const Story = require('./models/Story');
const Message = require('./models/Message');

const app = express();
app.use(cors());
app.use(express.json({ limit: '2mb' }));

const uploadDir = path.join(__dirname, 'uploads');
fs.mkdirSync(uploadDir, { recursive: true });
app.use('/uploads', express.static(uploadDir));

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => {
    const safeExt = path.extname(file.originalname).replace(/[^.a-zA-Z0-9]/g, '').slice(0, 10);
    cb(null, `${Date.now()}-${Math.round(Math.random() * 1e9)}${safeExt}`);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 150 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (file.mimetype.startsWith('video/')) return cb(null, true);
    cb(new Error('Only video files are accepted'));
  }
});

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, service: 'Blink API', database: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected' });
});

// Public creator feed. This corrects the original query, which only returned
// videos uploaded by the requested user.
app.get('/api/feed/:user_id', async (req, res) => {
  try {
    const feed = await Video.find({ privacy: 'public' })
      .sort({ created_at: -1 })
      .limit(30)
      .lean();
    res.json(feed);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database query failed' });
  }
});

app.post('/api/videos', async (req, res) => {
  try {
    const { user_id, username, caption, video_url, thumbnail_url, privacy } = req.body;
    if (!user_id || !username || !video_url) {
      return res.status(400).json({ error: 'user_id, username and video_url are required' });
    }
    const video = await Video.create({
      user_id, username, caption: caption || '', video_url,
      thumbnail_url: thumbnail_url || '',
      privacy: privacy === 'private' ? 'private' : 'public'
    });
    res.status(201).json(video);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not save video' });
  }
});

// Development upload endpoint. Use durable cloud storage before production.
app.post('/api/upload', upload.single('video'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Choose a video file' });
  const base = process.env.PUBLIC_API_URL || `${req.protocol}://${req.get('host')}`;
  res.status(201).json({
    video_url: `${base}/uploads/${req.file.filename}`,
    filename: req.file.filename
  });
});

app.post('/api/videos/:id/like', async (req, res) => {
  try {
    const { user_id } = req.body;
    if (!user_id) return res.status(400).json({ error: 'user_id is required' });
    const video = await Video.findById(req.params.id);
    if (!video) return res.status(404).json({ error: 'Video not found' });
    const liked = video.likes.includes(user_id);
    video.likes = liked ? video.likes.filter(id => id !== user_id) : [...video.likes, user_id];
    await video.save();
    res.json({ liked: !liked, likes_count: video.likes.length });
  } catch (err) {
    res.status(500).json({ error: 'Could not update like' });
  }
});

app.post('/api/videos/:id/comments', async (req, res) => {
  try {
    const { user_id, username, text } = req.body;
    if (!user_id || !username || !text || !text.trim()) {
      return res.status(400).json({ error: 'user_id, username and comment text are required' });
    }
    const video = await Video.findById(req.params.id);
    if (!video) return res.status(404).json({ error: 'Video not found' });
    video.comments.push({ user_id, username, text: text.trim() });
    await video.save();
    res.status(201).json(video.comments[video.comments.length - 1]);
  } catch (err) {
    res.status(500).json({ error: 'Could not add comment' });
  }
});

app.get('/api/stories', async (_req, res) => {
  try {
    const stories = await Story.find({ created_at: { $gte: new Date(Date.now() - 24 * 60 * 60 * 1000) } })
      .sort({ created_at: -1 }).limit(50).lean();
    res.json(stories);
  } catch (err) {
    res.status(500).json({ error: 'Could not load stories' });
  }
});

app.get('/api/messages/:user_id', async (req, res) => {
  try {
    const messages = await Message.find({
      $or: [{ sender_id: req.params.user_id }, { recipient_id: req.params.user_id }]
    }).sort({ created_at: -1 }).limit(100).lean();
    res.json(messages);
  } catch (err) {
    res.status(500).json({ error: 'Could not load messages' });
  }
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(400).json({ error: err.message || 'Request failed' });
});

const PORT = process.env.PORT || 3000;
mongoose.connect(process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/blink')
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB connection error:', err.message));

app.listen(PORT, '0.0.0.0', () => console.log(`Blink API listening on ${PORT}`));
