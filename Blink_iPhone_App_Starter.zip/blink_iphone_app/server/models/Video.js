const mongoose = require('mongoose');

const commentSchema = new mongoose.Schema({
  user_id: { type: String, required: true },
  username: { type: String, required: true },
  text: { type: String, required: true, maxlength: 1000 },
  created_at: { type: Date, default: Date.now }
});

const videoSchema = new mongoose.Schema({
  user_id: { type: String, required: true, index: true },
  username: { type: String, required: true },
  avatar_url: { type: String, default: '' },
  caption: { type: String, default: '', maxlength: 2200 },
  video_url: { type: String, required: true },
  thumbnail_url: { type: String, default: '' },
  privacy: { type: String, enum: ['public', 'private'], default: 'public', index: true },
  likes: { type: [String], default: [] },
  comments: { type: [commentSchema], default: [] },
  created_at: { type: Date, default: Date.now, index: true }
});

module.exports = mongoose.model('Video', videoSchema);
