const mongoose = require('mongoose');

const storySchema = new mongoose.Schema({
  user_id: { type: String, required: true },
  username: { type: String, required: true },
  avatar_url: { type: String, default: '' },
  media_url: { type: String, required: true },
  media_type: { type: String, enum: ['image', 'video'], default: 'image' },
  created_at: { type: Date, default: Date.now, expires: 86400 }
});

module.exports = mongoose.model('Story', storySchema);
