import React, { useEffect, useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, Image, Pressable, TextInput,
  FlatList, Alert, ActivityIndicator, Dimensions
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import * as ImagePicker from 'expo-image-picker';
import { VideoView, useVideoPlayer } from 'expo-video';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';

const API = process.env.EXPO_PUBLIC_API_URL || '';
const POSTER = require('./assets/blink-feed-poster.jpg');
const { width } = Dimensions.get('window');
const PURPLE = '#8B24FF';
const PEOPLE = [
  { name: 'Your Story', initials: '+', color: '#8B24FF' },
  { name: 'pretty_vee', initials: 'PV', color: '#d34cff' },
  { name: 'king_david', initials: 'KD', color: '#6d45ff' },
  { name: 'chioma_official', initials: 'CO', color: '#c23cff' },
  { name: 'jprince', initials: 'JP', color: '#7e35ff' },
  { name: 'Blink Creators', initials: 'BC', color: '#b34bff' }
];

function TabButton({ icon, label, active, onPress, center }) {
  return <Pressable onPress={onPress} style={styles.tabButton}>
    <View style={[styles.tabIcon, center && styles.createTab, active && !center && { backgroundColor: '#211039' }]}>
      <Ionicons name={icon} size={center ? 30 : 23} color={active || center ? '#b84aff' : '#c9c4d7'} />
    </View>
    <Text style={[styles.tabLabel, active && { color: '#fff' }]}>{label}</Text>
  </Pressable>;
}

function StoryRow() {
  return <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.storyRow}>
    {PEOPLE.map((person, index) => <Pressable key={person.name} style={styles.storyItem} onPress={() => Alert.alert(person.name, 'Story viewer is ready to connect to the Stories API.')}>
      <View style={[styles.storyRing, { borderColor: person.color }]}>
        <View style={styles.storyAvatar}><Text style={styles.storyInitial}>{person.initials}</Text></View>
        {index === 0 && <View style={styles.addStory}><Ionicons name="add" color="#fff" size={16}/></View>}
      </View>
      <Text numberOfLines={1} style={styles.storyName}>{person.name}</Text>
    </Pressable>)}
  </ScrollView>;
}

function VideoCard({ item, onLike, liked }) {
  const hasVideo = !!item.video_url;
  const player = useVideoPlayer(hasVideo ? item.video_url : null, p => { p.loop = true; });
  return <View style={styles.videoCard}>
    {hasVideo ? (
      <VideoView player={player} style={styles.videoBackground} contentFit="cover" nativeControls />
    ) : <Image source={POSTER} style={styles.videoBackground} resizeMode="cover" />}
    <View style={styles.videoTopLine}>
      <View style={styles.creatorLine}>
        <View style={styles.smallAvatar}><Text style={styles.avatarText}>{(item.username || 'B').slice(0,1).toUpperCase()}</Text></View>
        <View><Text style={styles.creatorName}>@{item.username || 'blink_creator'}  <Text style={{color:'#a84aff'}}>✓</Text></Text><Text style={styles.mutedSmall}>Original sound · Blink</Text></View>
      </View>
      <Pressable style={styles.followButton} onPress={() => Alert.alert('Follow', 'Connect account authentication to follow creators.') }><Text style={styles.followText}>Follow</Text></Pressable>
    </View>
    <View style={styles.engagement}>
      <Pressable onPress={onLike}><Ionicons name={liked ? 'heart' : 'heart-outline'} size={34} color={liked ? '#ff3f85' : '#fff'} /><Text style={styles.engagementText}>{item.likes?.length || '178.6K'}</Text></Pressable>
      <Pressable onPress={() => Alert.alert('Comments', 'Comments screen is ready for API connection.')}><Ionicons name="chatbubble-ellipses" size={31} color="#fff"/><Text style={styles.engagementText}>{item.comments?.length || '3,842'}</Text></Pressable>
      <Pressable onPress={() => Alert.alert('Share', 'Share this Blink video with your friends.')}><Ionicons name="arrow-redo" size={32} color="#fff"/><Text style={styles.engagementText}>12.4K</Text></Pressable>
      <Pressable onPress={() => Alert.alert('Gifts', 'Creator gifts can be connected after payments setup.')}><Ionicons name="gift" size={30} color="#fff"/></Pressable>
    </View>
    <View style={styles.videoCaption}>
      <Text style={styles.captionName}>@{item.username || 'chioma_official'}  <Text style={{color:'#a64cff'}}>✓</Text></Text>
      <Text style={styles.captionText}>{item.caption || 'Good vibes only 💜🔥'}</Text>
      <Text style={styles.hashtags}>#Blink #Dance #Nigeria #Vibes</Text>
      <Text style={styles.sound}><Ionicons name="musical-notes" size={13}/>  Original Sound - Blink</Text>
    </View>
  </View>;
}

export default function App() {
  const [tab, setTab] = useState('Home');
  const [category, setCategory] = useState('For You');
  const [feed, setFeed] = useState([]);
  const [loading, setLoading] = useState(false);
  const [liked, setLiked] = useState({});
  const [caption, setCaption] = useState('');
  const [picked, setPicked] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [query, setQuery] = useState('');

  const loadFeed = async () => {
    if (!API) return;
    setLoading(true);
    try {
      const response = await fetch(`${API}/api/feed/guest`);
      if (!response.ok) throw new Error('Feed request failed');
      setFeed(await response.json());
    } catch (e) {
      console.log(e);
    } finally { setLoading(false); }
  };

  useEffect(() => { loadFeed(); }, []);

  const chooseVideo = async () => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) return Alert.alert('Permission needed', 'Allow Blink to access your photo library to select a video.');
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['videos'], quality: 1 });
    if (!result.canceled) setPicked(result.assets[0]);
  };

  const publish = async () => {
    if (!picked) return Alert.alert('Choose a video', 'Select a video from your iPhone first.');
    if (!API) return Alert.alert('Connect the backend', 'Set EXPO_PUBLIC_API_URL in the mobile project to your running API URL.');
    setUploading(true);
    try {
      const data = new FormData();
      data.append('video', { uri: picked.uri, name: picked.fileName || 'blink-video.mp4', type: picked.mimeType || 'video/mp4' });
      const uploaded = await fetch(`${API}/api/upload`, { method: 'POST', body: data });
      const uploadJson = await uploaded.json();
      if (!uploaded.ok) throw new Error(uploadJson.error || 'Upload failed');
      const saved = await fetch(`${API}/api/videos`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_id: 'demo-user', username: 'junior_musk', caption, video_url: uploadJson.video_url, privacy: 'public' })
      });
      if (!saved.ok) throw new Error('Video uploaded but could not be published');
      setPicked(null); setCaption(''); setTab('Home'); await loadFeed();
      Alert.alert('Published', 'Your video has been added to the Blink feed.');
    } catch (e) { Alert.alert('Upload error', e.message); }
    finally { setUploading(false); }
  };

  const renderHome = () => <View style={styles.flex}>
    <View style={styles.header}>
      <View style={styles.brandMark}><Ionicons name="play" size={26} color="#080610"/></View>
      <Text style={styles.brand}>Blink</Text>
      <View style={{flex:1}}/>
      <Pressable onPress={() => setTab('Explore')}><Ionicons name="search" size={27} color="#fff"/></Pressable>
      <Pressable onPress={() => Alert.alert('Notifications', 'Your notifications will appear here.')}><Ionicons name="notifications-outline" size={27} color="#fff"/><View style={styles.badge}><Text style={styles.badgeText}>12</Text></View></Pressable>
      <Pressable onPress={() => setTab('Profile')} style={styles.profileDot}><Text style={styles.avatarText}>JM</Text></Pressable>
    </View>
    <StoryRow/>
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.categoryRow}>
      {['For You','Following','Trending','Music','Gaming','Comedy'].map(c => <Pressable key={c} onPress={() => setCategory(c)} style={[styles.categoryPill, category===c && styles.categoryActive]}><Text style={[styles.categoryText, category===c && {color:'#fff'}]}>{c}</Text></Pressable>)}
    </ScrollView>
    {loading && <ActivityIndicator color={PURPLE} style={{marginTop:12}}/>}
    <FlatList
      data={feed.length ? feed : [{ _id:'demo', username:'chioma_official', caption:'Good vibes only 💜🔥 #Blink #Dance #Nigeria #Vibes', video_url:null, likes:[], comments:[] }]}
      keyExtractor={(item,index) => item._id || String(index)}
      renderItem={({item}) => <VideoCard item={item} liked={!!liked[item._id]} onLike={() => setLiked(v => ({...v,[item._id]:!v[item._id]}))}/>}
      showsVerticalScrollIndicator={false}
    />
  </View>;

  const screenContent = () => {
    if (tab === 'Home') return renderHome();
    if (tab === 'Explore') return <View style={styles.page}>
      <Text style={styles.pageTitle}>Explore</Text>
      <TextInput value={query} onChangeText={setQuery} placeholder="Search creators, videos, topics..." placeholderTextColor="#827b91" style={styles.searchInput}/>
      <Text style={styles.sectionTitle}>Discover on Blink</Text>
      <View style={styles.exploreGrid}>{['Dance','Comedy','Music','Lifestyle','Sports','Gaming'].map((x,i)=><Pressable key={x} style={[styles.exploreTile,{backgroundColor:['#28104a','#17132a','#31113e','#24123d','#181a35','#32143f'][i]}]} onPress={()=>setCategory(x)}><Text style={styles.exploreTileText}>{x}</Text></Pressable>)}</View>
      <Text style={styles.muted}>Search creators, hashtags and videos. Results will load when the search API is connected.</Text>
    </View>;
    if (tab === 'Create') return <ScrollView style={styles.page} contentContainerStyle={{paddingBottom:40}}>
      <Text style={styles.pageTitle}>Create</Text>
      <Text style={styles.muted}>Share a moment with the Blink community.</Text>
      <Pressable style={styles.pickBox} onPress={chooseVideo}><Ionicons name="cloud-upload-outline" size={42} color="#b64cff"/><Text style={styles.pickTitle}>{picked ? 'Video selected' : 'Choose a video'}</Text><Text style={styles.muted}>{picked?.fileName || 'Select a video from your iPhone library'}</Text></Pressable>
      <TextInput value={caption} onChangeText={setCaption} placeholder="Write a caption..." placeholderTextColor="#827b91" style={[styles.searchInput,{height:110,textAlignVertical:'top'}]} multiline/>
      <Pressable style={styles.primaryButton} onPress={publish} disabled={uploading}>{uploading ? <ActivityIndicator color="#fff"/> : <Text style={styles.primaryText}>Publish video</Text>}</Pressable>
    </ScrollView>;
    if (tab === 'Inbox') return <View style={styles.page}>
      <Text style={styles.pageTitle}>Inbox</Text>
      <Text style={styles.muted}>Messages and private Story replies</Text>
      {['pretty_vee','king_david','chioma_official','jprince'].map((n,i)=><Pressable key={n} style={styles.messageRow} onPress={()=>Alert.alert(n,'Conversation view can be connected to the Messages API.')}>
        <View style={styles.messageAvatar}><Text style={styles.avatarText}>{n.slice(0,1).toUpperCase()}</Text></View>
        <View style={{flex:1}}><Text style={styles.creatorName}>{n}</Text><Text style={styles.mutedSmall}>{['Hey! Thanks for the follow.','Did you see my new video?','Replied to your story','Send me the link'][i]}</Text></View>
        <Text style={styles.mutedSmall}>{i+1}h</Text>
      </Pressable>)}
    </View>;
    return <View style={styles.page}>
      <Text style={styles.pageTitle}>Profile</Text>
      <View style={styles.profileHero}><View style={styles.bigAvatar}><Text style={styles.bigAvatarText}>JM</Text></View><Text style={styles.profileName}>Junior Musk</Text><Text style={styles.muted}>@junior_musk</Text><Text style={styles.profileBio}>Creator on Blink ✨ | Good vibes only</Text>
        <View style={styles.stats}><View><Text style={styles.statNum}>12.8K</Text><Text style={styles.mutedSmall}>Followers</Text></View><View><Text style={styles.statNum}>482</Text><Text style={styles.mutedSmall}>Following</Text></View><View><Text style={styles.statNum}>36</Text><Text style={styles.mutedSmall}>Videos</Text></View></View>
        <Pressable style={styles.outlineButton} onPress={()=>Alert.alert('Edit profile','Profile editing will connect to the user account API.') }><Text style={styles.followText}>Edit profile</Text></Pressable>
      </View>
      <Text style={styles.sectionTitle}>Your videos</Text><Image source={POSTER} style={styles.profilePoster}/>
    </View>;
  };

  return <SafeAreaView style={styles.safe}>
    <StatusBar style="light"/>
    <View style={styles.flex}>{screenContent()}</View>
    <View style={styles.bottomNav}>
      <TabButton icon="home" label="Home" active={tab==='Home'} onPress={()=>setTab('Home')}/>
      <TabButton icon="compass-outline" label="Explore" active={tab==='Explore'} onPress={()=>setTab('Explore')}/>
      <TabButton icon="add" label="Create" active={tab==='Create'} center onPress={()=>setTab('Create')}/>
      <TabButton icon="mail-outline" label="Inbox" active={tab==='Inbox'} onPress={()=>setTab('Inbox')}/>
      <TabButton icon="person-outline" label="Profile" active={tab==='Profile'} onPress={()=>setTab('Profile')}/>
    </View>
  </SafeAreaView>;
}

const styles = StyleSheet.create({
  safe:{flex:1,backgroundColor:'#07060d'},flex:{flex:1},header:{height:58,flexDirection:'row',alignItems:'center',paddingHorizontal:16,gap:16},
  brandMark:{width:34,height:34,borderRadius:11,backgroundColor:'#a52cff',alignItems:'center',justifyContent:'center',transform:[{rotate:'-4deg'}]},
  brand:{fontSize:27,fontWeight:'900',color:'#fff',letterSpacing:-1},badge:{position:'absolute',right:-5,top:-8,backgroundColor:'#ff315f',borderRadius:10,minWidth:17,height:17,alignItems:'center',justifyContent:'center'},
  badgeText:{fontSize:10,color:'#fff',fontWeight:'800'},profileDot:{width:34,height:34,borderRadius:17,backgroundColor:'#34204b',alignItems:'center',justifyContent:'center'},
  storyRow:{paddingHorizontal:12,paddingTop:10,paddingBottom:9,gap:13},storyItem:{width:74,alignItems:'center'},storyRing:{width:66,height:66,borderRadius:33,borderWidth:3,padding:3,alignItems:'center',justifyContent:'center'},
  storyAvatar:{flex:1,width:'100%',borderRadius:30,backgroundColor:'#241634',alignItems:'center',justifyContent:'center'},storyInitial:{fontWeight:'800',color:'#fff',fontSize:17},
  addStory:{position:'absolute',right:-2,bottom:0,width:22,height:22,borderRadius:11,backgroundColor:'#8b24ff',alignItems:'center',justifyContent:'center',borderWidth:2,borderColor:'#07060d'},
  storyName:{color:'#eeeaf5',fontSize:10,marginTop:5,maxWidth:74},categoryRow:{paddingHorizontal:12,paddingBottom:10,gap:8},
  categoryPill:{paddingHorizontal:17,paddingVertical:10,borderRadius:24,backgroundColor:'#171421'},categoryActive:{backgroundColor:'#8b24ff'},categoryText:{color:'#c9c3d4',fontSize:12,fontWeight:'700'},
  videoCard:{height:Math.max(460,Dimensions.get('window').height*0.62),backgroundColor:'#171321',overflow:'hidden',marginTop:2},videoBackground:{...StyleSheet.absoluteFillObject,width:'100%',height:'100%'},
  videoTopLine:{position:'absolute',top:14,left:14,right:14,flexDirection:'row',alignItems:'center',gap:10},creatorLine:{flexDirection:'row',alignItems:'center',gap:9,flex:1},
  smallAvatar:{width:39,height:39,borderRadius:20,backgroundColor:'#6b2fc3',alignItems:'center',justifyContent:'center',borderWidth:2,borderColor:'#bd49ff'},avatarText:{color:'#fff',fontWeight:'800'},
  creatorName:{color:'#fff',fontWeight:'800',fontSize:13},mutedSmall:{color:'#ddd7e7',fontSize:10,marginTop:3},followButton:{borderColor:'#eee',borderWidth:1,borderRadius:18,paddingHorizontal:15,paddingVertical:7},followText:{color:'#fff',fontWeight:'700',fontSize:12},
  engagement:{position:'absolute',right:12,bottom:100,alignItems:'center',gap:17},engagementText:{color:'#fff',fontWeight:'700',fontSize:10,marginTop:3},
  videoCaption:{position:'absolute',left:16,bottom:18,right:78},captionName:{color:'#fff',fontWeight:'800',fontSize:13},captionText:{color:'#fff',fontSize:14,marginTop:5,fontWeight:'600'},hashtags:{color:'#65c9ff',fontSize:12,marginTop:4},
  sound:{color:'#fff',fontSize:10,marginTop:9,backgroundColor:'#16131dbb',padding:7,borderRadius:15,alignSelf:'flex-start',overflow:'hidden'},
  bottomNav:{height:68,backgroundColor:'#090811',borderTopWidth:1,borderTopColor:'#21172f',flexDirection:'row',alignItems:'center',justifyContent:'space-around',paddingHorizontal:4},
  tabButton:{flex:1,alignItems:'center',justifyContent:'center',gap:2},tabIcon:{width:38,height:34,alignItems:'center',justifyContent:'center',borderRadius:18},createTab:{width:48,height:48,borderRadius:24,backgroundColor:'#7e22ff',marginTop:-18},
  tabLabel:{color:'#aaa4b6',fontSize:10,fontWeight:'600'},page:{flex:1,backgroundColor:'#07060d',padding:20},pageTitle:{color:'#fff',fontSize:28,fontWeight:'900',marginBottom:8},muted:{color:'#a49caf',fontSize:13,marginBottom:16},
  searchInput:{backgroundColor:'#171421',borderColor:'#352449',borderWidth:1,borderRadius:15,padding:15,color:'#fff',marginTop:16,marginBottom:18},
  sectionTitle:{color:'#fff',fontWeight:'800',fontSize:17,marginVertical:12},exploreGrid:{flexDirection:'row',flexWrap:'wrap',gap:10},exploreTile:{width:(width-50)/2,height:110,borderRadius:17,justifyContent:'flex-end',padding:14},exploreTileText:{color:'#fff',fontWeight:'800',fontSize:17},
  pickBox:{height:220,borderRadius:22,borderWidth:1,borderColor:'#5b2d83',borderStyle:'dashed',backgroundColor:'#151020',alignItems:'center',justifyContent:'center',gap:10,marginVertical:20},pickTitle:{color:'#fff',fontSize:18,fontWeight:'800'},
  primaryButton:{backgroundColor:'#8b24ff',borderRadius:28,padding:17,alignItems:'center',marginTop:8},primaryText:{color:'#fff',fontSize:16,fontWeight:'800'},
  messageRow:{flexDirection:'row',alignItems:'center',paddingVertical:15,borderBottomWidth:1,borderBottomColor:'#20192b',gap:12},messageAvatar:{width:48,height:48,borderRadius:24,backgroundColor:'#41205d',alignItems:'center',justifyContent:'center'},
  profileHero:{alignItems:'center',paddingVertical:25,backgroundColor:'#14101e',borderRadius:22,marginTop:12},bigAvatar:{width:90,height:90,borderRadius:45,backgroundColor:'#46226b',alignItems:'center',justifyContent:'center',borderWidth:3,borderColor:'#a438ff'},bigAvatarText:{color:'#fff',fontSize:25,fontWeight:'900'},
  profileName:{color:'#fff',fontSize:21,fontWeight:'900',marginTop:12},profileBio:{color:'#ddd7e7',marginTop:10},stats:{flexDirection:'row',justifyContent:'space-around',width:'100%',marginVertical:20},statNum:{color:'#fff',fontWeight:'900',fontSize:17,textAlign:'center'},
  outlineButton:{borderWidth:1,borderColor:'#8b24ff',borderRadius:20,paddingHorizontal:28,paddingVertical:9},profilePoster:{width:'100%',height:210,borderRadius:15,marginTop:8}
});
