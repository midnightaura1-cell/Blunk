# Blink — iPhone-first social app starter

This project turns the Blink screens already designed in the conversation into an iPhone-first Expo app with a working tab navigator and an Express/MongoDB API.

## What's included
- iPhone-first dark UI with purple accents.
- Bottom tabs: Home, Explore, Create, Inbox, Profile.
- Stories at the top of the For You feed.
- Video feed that loads from the Express API when configured.
- Create screen uses the iPhone photo/video picker and can submit a selected video to the API.
- Explore, Inbox and Profile starter screens.
- Express + Mongoose backend based on your original code, corrected so the feed returns public videos rather than only videos owned by the current user.
- Your generated Blink screen is included as a visual reference and feed poster.

## Important
The generated picture is a design reference/poster, not a playable video. Real human videos appear when creators upload video files. The starter includes a local upload endpoint for development. For production, connect durable cloud video storage (for example, Cloudinary, Mux, or S3) and a moderation workflow before public launch.

## 1. Start the backend
In Replit or a terminal, open the `server` folder and run:

```bash
npm install
```

Create a `.env` file using `.env.example` and set `MONGODB_URI`. Do not paste database passwords into source code.

```bash
npm run dev
```

The API starts on port 3000. Test `GET /api/health`.

## 2. Start the iPhone app
Open the `mobile` folder in a separate Replit project or local workspace:

```bash
npm install
npx expo start
```

Install Expo Go on your iPhone and scan the QR code.

Set `EXPO_PUBLIC_API_URL` to the backend's reachable HTTPS URL. Do not use `localhost` on a physical iPhone; `localhost` points to the phone itself. For local Mac development, use your Mac's LAN IP address. For Replit, use the published/reachable backend URL.

## 3. API endpoints
- `GET /api/health`
- `GET /api/feed/:user_id` — public feed; `user_id` can be `guest`
- `POST /api/videos` — create a video record
- `POST /api/upload` — upload a video file for development
- `POST /api/videos/:id/like`
- `POST /api/videos/:id/comments`
- `GET /api/stories`
- `GET /api/messages/:user_id`

## Before real public launch
Add verified authentication, rate limits, content reporting/blocking, privacy controls, age-appropriate safeguards, moderation, durable media storage, backups, and security review. The starter is a development foundation, not a production-ready social network.
